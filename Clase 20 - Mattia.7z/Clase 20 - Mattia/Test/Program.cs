﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Cartuchera<Utiles> myCartuchera = new Cartuchera<Utiles>("3p",7);
            Lapicera l1 = new Lapicera(10, "maped", "grueso", "rojo");
            Lapicera l2 = new Lapicera(10, "pen", "fino", "azul");
            Lapicera l3 = new Lapicera(10, "bic", "fino", "verde");
            Lapicera l4 = new Lapicera(10, "gol", "grueso", "amarillo");
            Goma g1 = new Goma(5, "faber", true);
            Goma g2 = new Goma(3, "rj", false);
            Goma g3 = new Goma(4, "boli", true);
            myCartuchera.elementoEntregadoEvent += new DelegadoEvent(Archivos.Guardar);

            myCartuchera.Agregar(l1);
            myCartuchera.Agregar(l2);
            myCartuchera.Agregar(l3);
            myCartuchera.Agregar(l4);
            myCartuchera.Agregar(g1);
            myCartuchera.Agregar(g2);
            myCartuchera.Agregar(g3);
            try
            {
                myCartuchera.Agregar(g3);
            }
            catch (CartucheraLlenaException e)
            {

            }
            try
            {
                myCartuchera.Agregar(g3);
            }
            catch (CartucheraLlenaException e)
            {

            }

           
            //Console.WriteLine(myCartuchera.ToString());
            myCartuchera.ListarBD();
            Console.ReadKey();
        }
    }
}
