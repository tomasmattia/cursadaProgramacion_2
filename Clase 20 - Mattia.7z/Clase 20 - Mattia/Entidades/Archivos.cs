﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Entidades
{
    public class Archivos
    {
        public static void Guardar(object obj,EventArgs e)
        {
            TextWriter escritor = new StreamWriter("Escritura.txt", true);
            escritor.WriteLine(DateTime.Now.ToString() + ((Cartuchera<Utiles>)obj).ultimo.ToString());
            escritor.Close();
        }

        
    }
}
