﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Lapicera:Utiles
    {
        protected string _color;
        protected string _trazo;

        public override int Precio 
        {
            get { return this._precio; }
            set { this._precio = value; }
        }

        public override string Marca 
        {
            get { return this._marca; } 
            set { this._marca=value; }
        }

        public Lapicera(int precio, string marca, string trazo, string color)
        {
            this._precio = precio;
            this._marca = marca;
            this._color = color;
            this._trazo = trazo;
        }

        public override string ToString()
        {
            return base.UtilesToString() + " Color:" + this._color + " Trazo: " + this._trazo;
        }
    }
}
