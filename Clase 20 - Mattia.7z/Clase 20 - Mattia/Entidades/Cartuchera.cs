﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.SqlClient;
using System.Data;

namespace Entidades
{
    public delegate void DelegadoEvent(object obj,EventArgs e);
    public class Cartuchera<T>
    {
        public SqlConnection sqlconexion;
        public SqlCommand sqlcomander;

        protected string _marca;
        protected int _capacidad;
        protected List<T> utiles;
        public T ultimo;
        public event DelegadoEvent elementoEntregadoEvent;

        public void Agregar(T obj)
        {
            if (this.utiles.Count + 1 <= this._capacidad)
            {
                this.utiles.Add(obj);
                this.ultimo = obj;
                this.elementoEntregadoEvent(this, EventArgs.Empty);
            }
            else
            {
                throw new CartucheraLlenaException("La cartuchera esta llena ya hay "+this._capacidad+" elementos");
            }
        }

        public Cartuchera(string marca,int capacidad)
        {
            this.utiles = new List<T>();
            this._capacidad = capacidad;
            this._marca = marca;
            sqlconexion = new SqlConnection(Entidades.Properties.Settings.Default.Setting);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Marca :" + this._marca + " Capacidad:" + this._capacidad);
            foreach (T obj in this.utiles)
            {
                sb.AppendLine(obj.ToString());
            }
            return sb.ToString();
        }

        //public List<Utiles> ListarBD()
        //{
        //    try
        //    {
        //        List<Utiles> listaUtiles = new List<Utiles>();
        //        sqlconexion.Open();
        //        sqlcomander = new SqlCommand();
        //        sqlcomander.Connection = sqlconexion;
        //        sqlcomander.CommandType = System.Data.CommandType.Text;
        //        sqlcomander.CommandText = "SELECT TOP 1000 [id],[marca],[precio],[color],[trazo],[soloLapiz],[tipo] FROM [Utiles].[dbo].[elementos]";
        //        SqlDataReader reader = sqlcomander.ExecuteReader();
        //        while (reader.Read())
        //        {
        //            if (reader[6] == "Lapicera")
        //            {
        //                listaUtiles.Add(new Lapicera(int.Parse(reader[2].ToString()), reader[1].ToString(), reader[4].ToString(), reader[3].ToString()));
        //            }
        //            else
        //            {
        //                if (reader[6] == "Goma")
        //                {
        //                    listaUtiles.Add(new Goma(int.Parse(reader[2].ToString()), reader[1].ToString(), bool.Parse(reader[5].ToString())));
        //                }
        //            }
        //        }
        //        reader.Close();
        //        sqlconexion.Close();
        //        return listaUtiles;
        //    }
        //    catch (Exception e)
        //    {
        //        return null;
        //    }
        //}

        public void ListarBD()
        {
            try
            {
                sqlconexion.Open();
                sqlcomander = new SqlCommand();
                sqlcomander.Connection = sqlconexion;
                sqlcomander.CommandType = System.Data.CommandType.Text;
                sqlcomander.CommandText = "SELECT TOP 1000 [id],[marca],[precio],[color],[trazo],[soloLapiz],[tipo] FROM [Utiles].[dbo].[elementos]";
                SqlDataReader reader = sqlcomander.ExecuteReader();
                while (reader.Read())
                {
                    for (int i = 0; i < 7; i++)
                    {
                        Console.Write(reader[i].ToString());
                    }
                    Console.Write("\n");
                }
                reader.Close();
                sqlconexion.Close();
            }
            catch (Exception e)
            {
            }
        }

        public static void MostrarBD(List<Utiles> lista)
        {
            foreach (Utiles i in lista)
            {
                i.ToString();
            }
        }
    }
}
