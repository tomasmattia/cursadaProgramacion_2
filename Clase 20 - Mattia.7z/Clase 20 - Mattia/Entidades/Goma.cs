﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Goma:Utiles
    {
        protected bool _soloLapiz;

        public override int Precio 
        {
            get { return this._precio; }
            set { this._precio = value; }
        }

        public override string Marca 
        {
            get { return this._marca; } 
            set { this._marca=value; }
        }

        public Goma(int precio, string marca, bool sololapiz)
        {
            this._precio = precio;
            this._marca = marca;
            this._soloLapiz = sololapiz;
        }

        public override string ToString()
        {
            return base.UtilesToString()+" "+"Solo Lapiz: "+this._soloLapiz;
        }
    }
}
